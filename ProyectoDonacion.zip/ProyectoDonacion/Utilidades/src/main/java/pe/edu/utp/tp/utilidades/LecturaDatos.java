package pe.edu.utp.tp.utilidades;

import java.util.Scanner;

public class LecturaDatos {
    static Scanner lector = new Scanner(System.in);

    // Método para leer una línea de texto del usuario
    public static String leerLinea(String mensaje) {
        System.out.println(mensaje);
        return lector.nextLine();
    }

    // Método para leer un número entero del usuario, con manejo de excepciones y repetición hasta obtener un valor válido
    public static int leerEntero(String mensaje) {
        System.out.println(mensaje);
        while (true) {
            try {
                int entero = lector.nextInt();
                // Se consume el salto de línea pendiente para evitar problemas en la siguiente lectura
                lector.nextLine();
                return entero;
            } catch (Exception e) {
                System.out.println("Se debe ingresar un número entero válido.");
                // Se consume el salto de línea pendiente en caso de excepción
                lector.nextLine();
            }
        }
    }

    // Método para leer un departamento válido del usuario, utilizando un conjunto predefinido de departamentos
    public static String leerDepartamento(String mensaje) {
        String departamento;
        final String[] departamentos = {
                "Amazonas", "Áncash", "Apurímac", "Arequipa", "Ayacucho", "Cajamarca", "Callao", "Cusco",
                "Huancavelica", "Huánuco", "Ica", "Junín", "La Libertad", "Lambayeque", "Lima", "Loreto",
                "Madre de Dios", "Moquegua", "Pasco", "Piura", "Puno", "San Martín", "Tacna", "Tumbes", "Ucayali"};
        boolean departamentoValido = false;
        do {
            departamento = leerLinea(mensaje);
            // Verificar si el departamento es válido comparándolo con los departamentos permitidos
            departamentoValido = false;
            for (String departamentoArreglo : departamentos) {
                if (departamento.equals(departamentoArreglo)) {
                    departamentoValido = true;
                    break;
                }
            }
            if (!departamentoValido) {
                System.out.println("Departamento inválido. Por favor, ingrese nuevamente.");
            }
        } while (!departamentoValido);
        return departamento;
    }

    // Método para leer un rango de edades válido del usuario, utilizando los métodos leerEdad y lectura repetida si el rango es inválido
    public static int[] leerRangoEdades(int limInferior, int limSuperior) {
        int[] rango = new int[2];
        boolean valorInvalido;

        do {
            rango[0] = leerEdad("Ingrese la edad inferior [" + limInferior + "-" + limSuperior + "]", limInferior, limSuperior);
            rango[1] = leerEdad("Ingrese la edad superior [" + limInferior + "-" + limSuperior + "]", limInferior, limSuperior);

            valorInvalido = rango[0] > rango[1];

            if (valorInvalido) {
                System.out.println("Edad o edades inválidas. La edad inferior debe ser menor o igual a la edad superior.");
            }

        } while (valorInvalido);

        return rango;
    }

    // Método para leer una edad válida del usuario, utilizando el método leerEntero y lectura repetida si la edad es inválida
    public static int leerEdad(String mensaje, int limInferior, int limSuperior) {
        boolean edadValida;
        int edad;

        do {
            edad = LecturaDatos.leerEntero(mensaje);
            edadValida = edad >= limInferior && edad <= limSuperior;

            if (!edadValida) {
                System.out.println("Edad inválida. Ingrese nuevamente.");
            }
        } while (!edadValida);

        return edad;
    }

    // Método para leer un sexo válido del usuario, utilizando un conjunto predefinido de sexos
    public static String leerSexo(String mensaje) {
        String sexo;
        final String[] valores = {"Hombre", "Mujer"};
        boolean sexoValido = false;

        do {
            sexo = leerLinea(mensaje);
            for (String valorSexo : valores) {
                if (sexo.equalsIgnoreCase(valorSexo)) {
                    sexoValido = true;
                    break;
                }
            }
            if (!sexoValido) {
                System.out.println("Sexo inválido. Por favor, ingrese nuevamente.");
            }
        } while (!sexoValido);

        return sexo;
    }

    // Método para leer una condición de donación válida del usuario, utilizando un conjunto predefinido de condiciones
    public static String leerCondicionDonacion(String mensaje) {
        String condicion;
        final String[] valores = {"SI", "NO", "NE"};
        boolean condicionValida = false;
        do {
            condicion = leerLinea(mensaje);
            for (String valorCondicion : valores) {
                if (condicion.equalsIgnoreCase(valorCondicion)) {
                    condicionValida = true;
                }
            }
            if (!condicionValida) {
                System.out.println("Condición inválida. Por favor, ingrese nuevamente.");
            }
        } while (!condicionValida);
        return condicion;
    }
}