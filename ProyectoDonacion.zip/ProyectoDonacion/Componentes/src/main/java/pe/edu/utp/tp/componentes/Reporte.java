package pe.edu.utp.tp.componentes;

import java.util.Comparator;
import java.util.List;
/* Clase que genera los reportes en ASCII con sus respectivos métodos y métodos auxiliares
   para realizar algunos cálculos necesarios para generar estos reportes.
 */
public class Reporte {
    // Método que genera el reporte A
    public static String reporteA(List<Donante> reporteFilas, String departamento) {
        reporteFilas.sort(Comparator.comparing(Donante::getDonacion));
        StringBuilder reporte = new StringBuilder();
        String encabezado = "Reporte A: Cantidad de personas por condición de donación dado un departamento (" + departamento + ")\n";
        reporte.append(encabezado);
        reporte.append("====================\n");
        reporte.append("COND.  CANT.  PORC.\n");
        reporte.append("====================\n");
        int totalCantidad = calcularTotalCantidad(reporteFilas);
        float porcentajeTotal = calcularPorcentajeTotal(reporteFilas);
        for (Donante fila : reporteFilas) {
            double porcentaje = (double) fila.getCantidad() / totalCantidad * 100;
            reporte.append(String.format(("%3s %8d %6.2f%%\n"), fila.getDonacion(), fila.getCantidad(), porcentaje));
        }
        reporte.append("====================\n");
        reporte.append(String.format("TOTAL %6d %6.2f%%\n", totalCantidad, porcentajeTotal));
        reporte.append("====================");
        return reporte.toString();
    }

    // Método que genera el reporte B
    public static String reporteB(List<Donante> reporteFilas, int edadMinima, int edadMaxima, String departamento, List<Donante> cantidadesGrupo) {
        reporteFilas.sort(Comparator.comparing(Donante::getProvincia));
        StringBuilder reporte = new StringBuilder();
        String encabezado = "Reporte B: Cantidad de personas por provincia, sexo y condición de donación\n" +
                "dado un rango de edades (" + edadMinima + "-" + edadMaxima + ") y un departamento (" +
                departamento + ")\n\n";
        reporte.append(encabezado);
        reporte.append("===================================================\n");
        reporte.append("PROVINCIA               SEXO    COND. CANT.  PORC.\n");
        reporte.append("===================================================\n");
        int totalCantidad = calcularTotalCantidad(reporteFilas);
        float porcentajeTotal = calcularPorcentajeTotal(reporteFilas);
        for (Donante fila : reporteFilas) {
            double porcentaje = (double) fila.getCantidad() / totalCantidad * 100;
            reporte.append(String.format("%-22s %-7s %4s %7d %6.2f%%\n",
                    fila.getProvincia(), fila.getSexo(), fila.getDonacion(), fila.getCantidad(), porcentaje));
        }
        reporte.append("===================================================\n");
        reporte.append(String.format("TOTAL %37d %6.2f%%\n", totalCantidad, porcentajeTotal));
        reporte.append("===================================================");
        return reporte.toString();
    }

    // Método que genera el reporte C
    public static String reporteC(List<Donante> reporteFilas, int edad, String sexo) {
        reporteFilas.sort(Comparator.comparing(Donante::getDepartamento));
        StringBuilder reporte = new StringBuilder();
        String encabezado = "Reporte C: Cantidad de donantes por departamento, dada una edad (" + edad + ") y un sexo (" + sexo + ")\n";
        reporte.append(encabezado);
        reporte.append("==============================\n");
        reporte.append("DEPARTAMENTO     CANT.  PORC.\n");
        reporte.append("==============================\n");
        int totalCantidad = calcularTotalCantidad(reporteFilas);
        float porcentajeTotal = calcularPorcentajeTotal(reporteFilas);
        for (Donante fila : reporteFilas) {
            double porcentaje = (double) fila.getCantidad() / totalCantidad * 100;
            reporte.append(String.format("%-15s %6d %6.2f%%\n", fila.getDepartamento(), fila.getCantidad(), porcentaje));
        }
        reporte.append("==============================\n");
        reporte.append(String.format("TOTAL %16d %6.2f%%\n", totalCantidad, porcentajeTotal));
        reporte.append("==============================");
        return reporte.toString();
    }

    // Método que genera el reporte D
    public static String reporteD(List<Donante> reporteFilas, String condicionDonacion) {
        StringBuilder reporte = new StringBuilder();
        String encabezado = "Reporte D: Cantidad de personas por departamento dada una condición de donación (" + condicionDonacion + ")\n";
        reporte.append(encabezado);
        reporte.append("==============================\n");
        reporte.append("DEPARTAMENTO  CANT.  PORC.\n");
        reporte.append("==============================\n");
        int totalCantidad = calcularTotalCantidad(reporteFilas);
        float porcentajeTotal = calcularPorcentajeTotal(reporteFilas);
        for (Donante fila : reporteFilas) {
            double porcentaje = (double) fila.getCantidad() / totalCantidad * 100;
            int cantidad = fila.getCantidad();
            String departamento = fila.getDepartamento();
            reporte.append(String.format("%-15s %7d %6.2f%%\n", departamento, cantidad, porcentaje));
        }
        reporte.append("==============================\n");
        reporte.append(String.format("TOTAL        %7d %6.2f%%\n", totalCantidad, porcentajeTotal));
        reporte.append("==============================");
        return reporte.toString();
    }

    // Método auxiliar para calcular la cantidad total en un reporte
    private static int calcularTotalCantidad(List<Donante> reporteFilas) {
        int totalCantidad = 0;
        for (Donante fila : reporteFilas) {
            totalCantidad += fila.getCantidad();
        }
        return totalCantidad;
    }

    // Método auxiliar para calcular el porcentaje total
    private static float calcularPorcentajeTotal(List<Donante> reporteFilas) {
        float porcentajeTotal = 0;
        for (Donante donante : reporteFilas) {
            porcentajeTotal += ((float) donante.getCantidad() / calcularTotalCantidad(reporteFilas)) * 100;
        }
        return porcentajeTotal;
    }
}