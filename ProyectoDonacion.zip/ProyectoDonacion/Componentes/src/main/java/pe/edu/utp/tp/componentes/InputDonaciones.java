package pe.edu.utp.tp.componentes;

import java.util.*;

public class InputDonaciones {
    // Método que convierte un arreglo de líneas de texto en un arreglo de objetos Donante
    public static Donante[] convertirArregloADonante(String[] lineas) {
        List<Donante> donantesList = new ArrayList<>();
        for (int i = 1; i < lineas.length; i++) {
            String linea = lineas[i];
            String[] segmento = linea.split(",");
            // Se verifica que cada línea tenga la cantidad de segmentos que se requiere, los cuales son 7
            if (segmento.length == 7) {
                String departamento = segmento[0].trim();
                String provincia = segmento[1].trim();
                String distrito = segmento[2].trim();
                String sexo = segmento[3].trim();
                int edad;
                int cantidad;
                try {
                    // Se convierte la edad y la cantidad a enteros
                    edad = Integer.parseInt(segmento[4].trim());
                    cantidad = Integer.parseInt(segmento[6].trim());
                } catch (NumberFormatException e) {
                    // Manejo de excepción si no se puede convertir la edad o cantidad a números enteros
                    System.err.println("Error al convertir edad o cantidad: " + e.getMessage());
                    continue; // Pasar al siguiente donante si ocurre un error
                }

                String donacion = segmento[5].trim();
                Donante persona = new Donante(departamento, provincia, distrito, sexo, edad, donacion, cantidad);
                donantesList.add(persona);
            }
        }
        return donantesList.toArray(new Donante[0]);
    }

    // Método que realiza el conteo de donaciones en un departamento determinado
    public static String conteoA(Donante[] donantes, String departamento) {
        int[] contador = new int[3];
        for (Donante donante : donantes) {
            if (donante.getDepartamento().equals(departamento)) {
                String condicion = donante.getDonacion();
                switch (condicion) {
                    case "SI" -> contador[0] += donante.getCantidad();
                    case "NO" -> contador[1] += donante.getCantidad();
                    case "NE" -> contador[2] += donante.getCantidad();
                }
            }
        }
        List<Donante> reporteFilas = new ArrayList<>();
        reporteFilas.add(new Donante("SI", contador[0]));
        reporteFilas.add(new Donante("NO", contador[1]));
        reporteFilas.add(new Donante("NE", contador[2]));
        return Reporte.reporteA(reporteFilas, departamento);
    }

    // Método que realiza el conteo de donaciones filtradas por departamento y rango de edad
    public static String conteoB(Donante[] donantes, String departamentoBuscado, int edadMinima, int edadMaxima) {
        List<Donante> reporte = new ArrayList<>();

        // Filtrar los donantes que cumplen con el departamento y el rango de edad especificados
        List<Donante> personasFiltradas = Arrays.stream(donantes)
                .filter(persona -> persona.getDepartamento().equalsIgnoreCase(departamentoBuscado))
                .filter(persona -> persona.getEdad() >= edadMinima && persona.getEdad() <= edadMaxima)
                .toList();

        // Estructura de datos para almacenar cantidades de donaciones por provincia, sexo y condición
        List<Donante> cantidadesGrupo = new ArrayList<>();

        // Realizar el conteo de donaciones por provincia, sexo y condición
        for (Donante persona : personasFiltradas) {
            String provincia = persona.getProvincia();
            String sexo = persona.getSexo();
            String condicion = persona.getDonacion();
            int cantidad = persona.getCantidad();
            // Buscar si ya existe un grupo con los mismos atributos
            boolean grupoExiste = false;
            for (Donante grupo : cantidadesGrupo) {
                if (grupo.getProvincia().equals(provincia) && grupo.getSexo().equals(sexo) && grupo.getDonacion().equals(condicion)) {
                    grupo.aumentarCantidad(cantidad); // Aumentar la cantidad de donaciones
                    grupoExiste = true;
                }
            }
            if (!grupoExiste) {
                Donante grupo = new Donante(provincia, sexo, condicion, cantidad);
                cantidadesGrupo.add(grupo);
            }
        }
        // Crear una lista de objetos Donante con los resultados del conteo
        for (Donante grupo : cantidadesGrupo) {
            reporte.add(new Donante(grupo.getProvincia(), grupo.getSexo(), grupo.getDonacion(), grupo.getCantidad()));
        }
        return Reporte.reporteB(reporte, edadMinima, edadMaxima, departamentoBuscado, cantidadesGrupo);
    }

    // Método que realiza el conteo de donantes que han donado en un departamento específico con una edad y sexo determinado
    public static String conteoC(Donante[] donantes, int edad, String sexo) {
        List<Donante> reporteFilas = new ArrayList<>();

        // Mapa para almacenar la cantidad de donantes por departamento
        List<Donante> contadorPorDepartamento = new ArrayList<>();

        // Realizar el conteo de donantes que cumplen con la edad, el sexo y que han donado ("SI")
        for (Donante donante : donantes) {
            if (donante.getDonacion().equals("SI") && donante.getEdad() == edad && donante.getSexo().equalsIgnoreCase(sexo)) {
                String departamento = donante.getDepartamento();
                int cantidad = donante.getCantidad();

                // Buscar si ya existe un departamento en la lista
                boolean departamentoExiste = false;
                for (Donante fila : contadorPorDepartamento) {
                    if (fila.getDepartamento().equals(departamento)) {
                        fila.setCantidad(fila.getCantidad() + cantidad);
                        departamentoExiste = true;
                        break;
                    }
                }
                if (!departamentoExiste) {
                    Donante nuevaFila = new Donante(cantidad, departamento);
                    contadorPorDepartamento.add(nuevaFila);
                }
            }
        }

        // Crear una lista de objetos Donante con los resultados del conteo
        for (Donante fila : contadorPorDepartamento) {
            int cantidadDonantes = fila.getCantidad();
            reporteFilas.add(new Donante(cantidadDonantes, fila.getDepartamento()));
        }
        return Reporte.reporteC(reporteFilas, edad, sexo);
    }

    // Método que realiza el conteo de donantes por departamento que tengan una condición de donación específica
    public static String conteoD(Donante[] donantes, String condicionDonacion) {
        List<Donante> reporteFilas = new ArrayList<>();
        for (Donante donante : donantes) {
            String departamento = donante.getDepartamento();
            String condicion = donante.getDonacion();
            int cantidad = donante.getCantidad();
            if (condicion.equals(condicionDonacion)) {
                boolean departamentoExiste = false;
                for (Donante fila : reporteFilas) {
                    if (fila.getDepartamento().equals(departamento)) {
                        fila.setCantidad(fila.getCantidad() + cantidad);
                        departamentoExiste = true;
                        break;
                    }
                }
                if (!departamentoExiste) {
                    Donante nuevaFila = new Donante(cantidad, departamento);
                    reporteFilas.add(nuevaFila);
                }
            }
        }
        return Reporte.reporteD(reporteFilas, condicionDonacion);
    }
}
