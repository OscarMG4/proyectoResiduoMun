package pe.edu.utp.tp.componentes;
import pe.edu.utp.tp.utilidades.LecturaDatos;
import pe.edu.utp.tp.utilidades.ManejoArchivos;
import java.io.IOException;
public class Menu {
    // Atributos de esta clase
    private final Donante[] donantes;
    private final String usuario;
    private final String separador = "--------------------------------------------------";
    private String encabezadoMenu;
    private int modulo = 0;
    private String reporte;
    private boolean reporteGenerado = false;

    // Constructor parametrizado sobrecargado para donantes
    public Menu(Donante[] donantes, String usuario) {
        this.donantes = donantes;
        this.usuario = usuario;
    }

    // Método que permite al usuario acceder al menú principal y realizar operaciones
    public void accederMenu() {
        // Opciones del menú principal
        String opciones = """
                1. Cantidad de personas por condición de donación
                dado un departamento.
                2. Cantidad de personas por provincia, sexo y
                condición de donación dado un rango de edades y
                un departamento.
                3. Cantidad de donantes por departamento dada una
                edad y sexo.
                4. Cantidad de personas por departamento dada una
                condición de donación.
                0. FINALIZAR PROGRAMA""";
        // Se formatea el menú principal
        String menuPrincipal = formatearMenu("MENÚ PRINCIPAL", separador, opciones, 4);
        // Ciclo para mostrar el menú principal y permitir la selección de opciones
        while (true){
            int opcion = LecturaDatos.leerEntero(menuPrincipal);
            switch (opcion) {
                case 1 -> {
                    this.encabezadoMenu = "MÓDULO 01 – PERSONAS POR CONDICIÓN DE DONACIÓN";
                    modulo = 1;
                    submenu();
                }
                case 2 -> {
                    this.encabezadoMenu = "MÓDULO 02 – PERSONAS POR PROVINCIA, SEXO Y \nCONDICIÓN DE DONACION";
                    modulo = 2;
                    submenu();
                }
                case 3 -> {
                    this.encabezadoMenu = "MÓDULO 03 – PERSONAS POR DEPARTAMENTO \nDADA UNA EDAD Y SEXO";
                    modulo = 3;
                    submenu();
                }
                case 4 -> {
                    this.encabezadoMenu = "MÓDULO 04 – PERSONAS POR DEPARTAMENTO \nDADA UNA CONDICIÓN DE DONACIÓN";
                    modulo = 4;
                    submenu();
                }
                // Se finaliza el programa si se selecciona la opción 0
                case 0 -> {
                    System.out.println("Finalizando el programa...");
                    return;
                }
                default -> System.out.println("Opción inválida. Por favor, ingrese un valor válido.");
            }
        }
    }

    // Método que permite al usuario acceder a los submenús y realizar operaciones
    private void submenu(){
        // Opciones del submenú
        String submenuOpciones = """
                1. Imprimir por pantalla.
                2. Exportar a archivo plano.
                0. Volver al menú principal""";
        String menu = formatearMenu(encabezadoMenu, separador, submenuOpciones,2);
        // Ciclo para mostrar el submenú y permitir la selección de opciones
        while (true){
            int opcion = LecturaDatos.leerEntero(menu);
            switch (opcion) {
                case 1 -> {
                    // Se realizar la operación correspondiente al módulo y se muestra el resultado en la consola
                    realizarOperacion();
                    System.out.println(reporte);
                    reporteGenerado = true;
                }
                case 2 -> {
                    // Se guarda el reporte generado en un archivo si existe un reporte previamente realizado
                    if (reporteGenerado) {
                        guardarReporte();
                    } else {
                        System.out.println("No se ha generado ningún reporte");
                    }
                }
                case 0 -> {
                    // Se vuelve al menú principal y se reinicia la generación de reportes
                    reporteGenerado = false;
                    System.out.println("Volviendo al menú principal...");
                    return;
                }
                default -> System.out.println("Opción inválida. Por favor, ingrese un valor válido.");
            }
        }
    }

    // Método que realiza la operación correspondiente al módulo seleccionado
    private void realizarOperacion(){
        try {
            switch (modulo) {
                case 1 -> moduloA();
                case 2 -> moduloB();
                case 3 -> moduloC();
                case 4 -> moduloD();
                default -> throw new IllegalArgumentException("Valor de módulo inválido. " +
                        "Error en el método realizarOperacion - Clase Menu.");
            }
        } catch (IllegalArgumentException e) {
            // Manejo de excepciones para IllegalArgumentException
            ManejoArchivos.manejarExcepcion(usuario, "IllegalArgumentException", e.getMessage());
            throw new RuntimeException(e.getMessage());
        }
    }

    // Método correspondiente al módulo A
    private void moduloA(){
        String departamento = LecturaDatos.leerDepartamento("Ingrese un departamento: ");
        reporte = InputDonaciones.conteoA(donantes, departamento);
    }
    // Método correspondiente al módulo B
    private void moduloB(){
        int[] rangoEdades = LecturaDatos.leerRangoEdades(18,25);
        String departamento = LecturaDatos.leerDepartamento("Ingrese un departamento: ");
        reporte = InputDonaciones.conteoB(donantes, departamento, rangoEdades[0], rangoEdades[1]);
    }
    // Método correspondiente al módulo C
    private void moduloC() {
        int edad = LecturaDatos.leerEdad("Ingrese una edad [18-25]: ", 18, 25);
        String sexo = LecturaDatos.leerSexo("Ingrese un sexo [Hombre/Mujer]: ");
        reporte = InputDonaciones.conteoC(donantes, edad, sexo);
    }
    // Método correspondiente al módulo D
    private void moduloD() {
        String condicion = LecturaDatos.leerCondicionDonacion("Ingrese una condición de donación [SI/NO/NE]: ");
        reporte = InputDonaciones.conteoD(donantes, condicion);
    }

    // Método que permite guardar el reporte generado en un archivo de texto
    private void guardarReporte() {
        try {
            String nombreArchivo = LecturaDatos.leerLinea("Ingrese el nombre del archivo a guardar: ");
            String rutaGuardado = "reportesGuardados\\" + nombreArchivo + ".txt";
            ManejoArchivos.guardarArchivo(reporte, rutaGuardado);
            System.out.println("Archivo guardado como: " + rutaGuardado);
        } catch (IOException e) {
            // Manejo de excepciones para IOException
            System.err.println("Error al guardar el archivo: " + e.getMessage());
        }
    }

    // Método que formatea el menú con un encabezado, separador y contenido
    private static String formatearMenu(String encabezado, String separador, String contenido, int opciones) {
        return String.format("%1$s\n%2$s\n%1$s\n%3$s\n%1$s\nIngrese opción [1 - %4$d]", separador, encabezado,
                contenido, opciones);
    }
}