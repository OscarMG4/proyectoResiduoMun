package pe.edu.utp.tp.componentes;

public class Donante {
    // Atributos de la clase Donante
    private String departamento;
    private String provincia;
    private String distrito;
    private String sexo;
    private int edad;
    private String donacion;
    private int cantidad;
    private double porcentaje;

    // Constructor completo
    public Donante(String departamento, String provincia, String distrito, String sexo, int edad, String donacion, int cantidad) {
        this.departamento = departamento;
        this.provincia = provincia;
        this.distrito = distrito;
        this.sexo = sexo;
        this.edad = edad;
        this.donacion = donacion;
        this.cantidad = cantidad;
    }

    // Constructor parametrizado para donaciones
    public Donante(String donacion, int cantidad) {
        this.donacion = donacion;
        this.cantidad = cantidad;
    }

    // Constructor parametrizado para provincia, sexo y donaciones
    public Donante(String provincia, String sexo, String donacion, int cantidad) {
        this.provincia = provincia;
        this.sexo = sexo;
        this.donacion = donacion;
        this.cantidad = cantidad;
    }

    // Constructor parametrizado para cantidad y departamento
    public Donante(int cantidad, String departamento) {
        this.cantidad = cantidad;
        this.departamento = departamento;
    }

    // Getters y setters
    public String getDepartamento() {
        return departamento;
    }
    public void setDepartamento(String departamento) {
        this.departamento = departamento;
    }

    public String getProvincia() {
        return provincia;
    }
    public void setProvincia(String provincia) {
        this.provincia = provincia;
    }

    public String getDistrito() {
        return distrito;
    }
    public void setDistrito(String distrito) {
        this.distrito = distrito;
    }

    public String getSexo() {
        return sexo;
    }
    public void setSexo(String sexo) {
        this.sexo = sexo;
    }

    public int getEdad() {
        return edad;
    }
    public void setEdad(int edad) {
        this.edad = edad;
    }

    public String getDonacion() {
        return donacion;
    }
    public void setDonacion(String donacion) {
        this.donacion = donacion;
    }

    public int getCantidad() {
        return cantidad;
    }
    public void setCantidad(int cantidad) {
        this.cantidad = cantidad;
    }

    public void aumentarCantidad(int cantidad) {
        this.cantidad += cantidad;
    }

    public double getPorcentaje() {
        return porcentaje;
    }
}
