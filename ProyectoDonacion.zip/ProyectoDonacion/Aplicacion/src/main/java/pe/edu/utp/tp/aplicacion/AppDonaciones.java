package pe.edu.utp.tp.aplicacion;

import pe.edu.utp.tp.componentes.Donante;
import pe.edu.utp.tp.componentes.InputDonaciones;
import pe.edu.utp.tp.componentes.Menu;
import pe.edu.utp.tp.utilidades.ManejoArchivos;
import pe.edu.utp.tp.utilidades.ValidacionCredenciales;

import java.io.IOException;

public class AppDonaciones {
    public static void main(String[] args) {
        // Ruta del archivo CSV que contiene los datos de donantes
        String rutaArchivos = "Componentes\\src\\main\\resources\\Registro 2022 Donantes Órganos Perú (DATASET).csv";
        // Objeto para validar las credenciales de usuario desde el archivo "usuarios.txt"
        ValidacionCredenciales inicioSesion = new ValidacionCredenciales("Componentes\\src\\main\\resources\\usuarios.txt", 3);
        // Se valida las credenciales del usuario
        boolean usuarioValido = inicioSesion.validarUsuario();
        if (usuarioValido) {
            String[] lineas;
            try {
                // Se lee el archivo CSV y se obtiene las líneas de texto como un arreglo de cadenas
                lineas = ManejoArchivos.leerArchivoComoArreglo(rutaArchivos);
            } catch (IOException e) {
                // Manejo de excepciones en caso de error al leer el archivo
                ManejoArchivos.manejarExcepcion(inicioSesion.getUsuario(), "IOExcepcion", e.getMessage());
                throw new RuntimeException(e);
            }
            // Se convierte el arreglo de líneas en un arreglo de objetos Donante
            Donante[] baseDatos = InputDonaciones.convertirArregloADonante(lineas);
            // Se crea un objeto Menu con la base de datos de donantes y el usuario actual
            Menu menu = new Menu(baseDatos, inicioSesion.getUsuario());
            // Se accede al menú principal
            menu.accederMenu();
        }
    }
}